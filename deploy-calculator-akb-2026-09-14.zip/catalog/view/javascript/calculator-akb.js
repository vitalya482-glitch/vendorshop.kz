// VENDSHOP_CALC: логика калькулятора АКБ
// VENDSHOP_CALC_STAGE7: два режима расчета, новые стандарты напряжения, проект заказа из калькуляции
(function() {
  function initBatteryCalculator() {
    var calcMode = document.getElementById('calcMode');
    var calcModeUpsBtn = document.getElementById('calcModeUpsBtn');
    var calcModeCustomBtn = document.getElementById('calcModeCustomBtn');
    var averagePower = document.getElementById('loadPower');
    var maxPower = document.getElementById('maxLoadPower');
    var powerUnit = document.getElementById('powerUnit');
    var backupTime = document.getElementById('backupTime');
    var systemVoltage = document.getElementById('systemVoltage');
    var customSeries = document.getElementById('customSeries');
    var batteryType = document.getElementById('batteryType');
    var lifepo4Variant = document.getElementById('lifepo4Variant');
    var lifepo4VariantCellBtn = document.getElementById('lifepo4VariantCellBtn');
    var lifepo4VariantBatteryBtn = document.getElementById('lifepo4VariantBatteryBtn');
    var efficiency = document.getElementById('efficiency');
    var reservePercent = document.getElementById('reservePercent');
    var batteryAh = document.getElementById('batteryAh');
    var customBatteryAh = document.getElementById('customBatteryAh');
    var batteryAhLabel = document.getElementById('batteryAhLabel');
    var requiredCapacityAh = document.getElementById('requiredCapacityAh');
    var customMaxCurrent = document.getElementById('customMaxCurrent');
    var customBatteryWrap = document.getElementById('customBatteryWrap');
    var calculateButton = document.getElementById('calculateBattery');
    var calculateOrderButton = document.getElementById('createProjectOrder');
    var powerUnitWBtn = document.getElementById('powerUnitWBtn');
    var powerUnitKwBtn = document.getElementById('powerUnitKwBtn');
    var resultPlaceholder = document.getElementById('resultPlaceholder');
    var resultBody = document.getElementById('resultBody');
    var productsSection = document.getElementById('batteryProductsSection');
    var systemVoltageCustomOption = document.getElementById('systemVoltageCustomOption');
    var groups = {
      powerUnit: document.getElementById('groupPowerUnit'),
      loadPower: document.getElementById('groupLoadPower'),
      maxLoadPower: document.getElementById('groupMaxLoadPower'),
      backupTime: document.getElementById('groupBackupTime'),
      batteryType: document.getElementById('groupBatteryType'),
      lifepo4Variant: document.getElementById('groupLifepo4Variant'),
      efficiency: document.getElementById('groupEfficiency'),
      reserve: document.getElementById('groupReservePercent'),
      requiredCapacity: document.getElementById('groupRequiredCapacity'),
      customCurrent: document.getElementById('groupCustomCurrent'),
      customSeries: document.getElementById('groupCustomSeries'),
      customVoltageHelp: document.getElementById('customVoltageHelpBox')
    };

    if (!calcMode || !averagePower || !maxPower || !powerUnit || !backupTime || !systemVoltage || !batteryType || !efficiency || !reservePercent || !batteryAh || !customBatteryAh || !customMaxCurrent || !calculateButton) {
      return;
    }

    var calculatorData = window.VENDSHOP_CALC_DATA || {};
    calculatorData.cells = calculatorData.cells || [];
    calculatorData.bms = calculatorData.bms || [];
    calculatorData.batteries = calculatorData.batteries || [];

    var state = {
      selectedCellId: null,
      selectedBmsId: null,
      requiredSeries: 0,
      requiredCapacity: 0,
      requiredCurrent: 0,
      totalCells: 0,
      batteryOptionsLoaded: false,
      lastUpsBatteryType: batteryType.value || 'lifepo4'
    };

    var batteryProfiles = {
      agm: { dod: 0.5, text: 'AGM для резервного питания' },
      gel: { dod: 0.6, text: 'GEL для стабильной работы' },
      lifepo4: { dod: 0.9, text: 'LiFePO4 для частых циклов' }
    };

    var standardBatteryOptions = [7, 9, 12, 18, 26, 33, 40, 45, 55, 65, 75, 90, 100, 120, 150, 200, 250];
    var lifepo4VoltageSeriesMap = {
      12: 4,
      24: 8,
      36: 12,
      48: 16,
      60: 20,
      72: 24
    };

    function toNumber(value) {
      return parseFloat(value) || 0;
    }

    function getCalcMode() {
      return calcMode.value === 'custom' ? 'custom' : 'ups';
    }

    function getActiveBatteryType() {
      return getCalcMode() === 'custom' ? 'lifepo4' : batteryType.value;
    }

    function getLifepo4Variant() {
      return lifepo4Variant && lifepo4Variant.value === 'battery' ? 'battery' : 'cell';
    }

    function isReadyBatteryMode() {
      return getActiveBatteryType() === 'lifepo4' && getLifepo4Variant() === 'battery';
    }

    function isCustomMode() {
      return getCalcMode() === 'custom';
    }

    function toWatts(value) {
      var numeric = toNumber(value);
      return powerUnit.value === 'kw' ? numeric * 1000 : numeric;
    }

    function ceilToOneDecimal(num) {
      return Math.ceil(num * 10) / 10;
    }

    function escapeHtml(str) {
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    function setText(id, value) {
      var element = document.getElementById(id);
      if (element) {
        element.textContent = value;
      }
    }

    function getRequiredSeries(voltage) {
      var normalized = Math.round(toNumber(voltage));
      if (lifepo4VoltageSeriesMap[normalized]) {
        return lifepo4VoltageSeriesMap[normalized];
      }
      return Math.max(1, Math.round(normalized / 3.2));
    }

    function getSeriesForCurrentMode() {
      if (isCustomMode() && systemVoltage.value === 'custom') {
        return Math.max(4, Math.min(24, parseInt(customSeries.value, 10) || 4));
      }
      return getActiveBatteryType() === 'lifepo4'
        ? getRequiredSeries(systemVoltage.value)
        : Math.max(1, Math.round(toNumber(systemVoltage.value) / 12));
    }

    function getWorkingVoltage() {
      if (isCustomMode() && systemVoltage.value === 'custom') {
        return getSeriesForCurrentMode() * 3.2;
      }
      return Math.max(1, toNumber(systemVoltage.value));
    }

    function getSelectedCapacityAh() {
      if (getActiveBatteryType() === 'lifepo4') {
        return Math.max(0, toNumber(batteryAh.value));
      }

      if (batteryAh.value === 'manual') {
        return Math.max(0, toNumber(customBatteryAh.value));
      }

      return Math.max(0, toNumber(batteryAh.value));
    }

    function formatPowerForUnit(valueWatts, unit) {
      var result = unit === 'kw' ? (valueWatts / 1000) : valueWatts;
      return unit === 'kw' ? result.toFixed(2).replace(/\.00$/, '') : String(Math.round(result));
    }

    function formatMoney(value) {
      var numeric = toNumber(value);
      var currency = calculatorData.currency || {};
      var decimals = typeof currency.decimal_place === 'number' ? currency.decimal_place : 2;
      var parts = numeric.toFixed(decimals).split('.');
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
      var result = parts.join(decimals > 0 ? '.' : '');
      return (currency.symbol_left || '') + result + (currency.symbol_right || '');
    }

    function hasPrice(item) {
      return item && !isNaN(toNumber(item.price)) && toNumber(item.price) > 0;
    }

    function getPriceText(item) {
      return hasPrice(item) ? formatMoney(item.price) : (calculatorData.text_price_not_available || 'Цена не указана');
    }

    function setCostField(id, value) {
      setText(id, value || '—');
    }

    function getProductImageMarkup(item) {
      if (!item || !item.image) return '';
      return '<div class="vc-product-image"><img src="' + escapeHtml(item.image) + '" alt="" loading="lazy"></div>';
    }

    function resetCostSummary() {
      state.selectedBmsId = null;
      var box = document.getElementById('batteryCostSummary');
      if (box) box.style.display = 'none';
      if (calculateOrderButton) calculateOrderButton.style.display = 'none';
      setCostField('costCellUnit', '—');
      setCostField('costCellQty', '—');
      setCostField('costCellTotal', '—');
      setCostField('costBmsUnit', '—');
      setCostField('costBmsQty', '—');
      setCostField('costBmsTotal', '—');
      setCostField('costGrandTotal', '—');
    }

    function updateCostLabels() {
      var readyBattery = isReadyBatteryMode();
      setText('costCellUnitLabel', readyBattery ? 'Цена за 1 батарею' : (calculatorData.text_price_cell_unit || 'Цена за 1 ячейку'));
      setText('costCellQtyLabel', readyBattery ? 'Количество батарей' : (calculatorData.text_price_cell_qty || 'Количество ячеек'));
      setText('costCellTotalLabel', readyBattery ? 'Итого по батареям' : (calculatorData.text_price_cell_total || 'Итого по ячейкам'));
    }

    function updateCostSummary(selectedCell, selectedBms) {
      var box = document.getElementById('batteryCostSummary');
      if (!box) return;
      if (!selectedCell) {
        box.style.display = 'none';
        if (calculateOrderButton) calculateOrderButton.style.display = 'none';
        return;
      }

      var cellQty = selectedCell.totalCells || selectedCell.totalUnits || state.totalCells || 0;
      var cellTotal = hasPrice(selectedCell) ? toNumber(selectedCell.price) * cellQty : 0;
      var bmsQty = selectedBms ? 1 : 0;
      var bmsTotal = selectedBms && hasPrice(selectedBms) ? toNumber(selectedBms.price) * bmsQty : 0;
      var grandTotal = cellTotal + bmsTotal;

      setCostField('costCellUnit', getPriceText(selectedCell));
      setCostField('costCellQty', cellQty ? String(cellQty) + ' шт.' : '—');
      setCostField('costCellTotal', hasPrice(selectedCell) ? formatMoney(cellTotal) : (calculatorData.text_price_not_available || 'Цена не указана'));
      setCostField('costBmsUnit', selectedBms ? getPriceText(selectedBms) : '—');
      setCostField('costBmsQty', bmsQty ? String(bmsQty) + ' шт.' : '—');
      setCostField('costBmsTotal', selectedBms ? (hasPrice(selectedBms) ? formatMoney(bmsTotal) : (calculatorData.text_price_not_available || 'Цена не указана')) : '—');
      setCostField('costGrandTotal', (hasPrice(selectedCell) || (selectedBms && hasPrice(selectedBms))) ? formatMoney(grandTotal) : (calculatorData.text_price_not_available || 'Цена не указана'));
      box.style.display = '';
      if (calculateOrderButton) calculateOrderButton.style.display = '';
    }

    function updateSelectedAssemblySummary(item) {
      if (!item) return;

      var readyBattery = item.mode === 'battery';
      var seriesCount = readyBattery ? 1 : (item.seriesCount || state.requiredSeries || 1);
      var parallelCount = item.parallelCount || item.totalUnits || 1;
      var totalCount = item.totalCells || item.totalUnits || (seriesCount * parallelCount);
      var totalCapacityAh = item.totalCapacityAh || (toNumber(item.capacity_ah) * parallelCount);

      setText('requiredCapacity', ceilToOneDecimal(totalCapacityAh) + ' А·ч');
      setText('baseCapacity', ceilToOneDecimal(totalCapacityAh) + ' А·ч');
      setText('batteryCountBadge', totalCount + ' шт.');
      setText('batteryCount', totalCount + ' шт.');
      setText('energyKwh', toNumber(item.packEnergyKwh).toFixed(1) + ' кВт·ч');

      if (readyBattery) {
        setText('batteryConfig', '1 готовая сборка × ' + parallelCount + ' параллельно');
        setText('batterySeriesParallel', Math.round(toNumber(item.voltage)) + 'V-' + parallelCount + 'P');
      } else {
        setText('batteryConfig', seriesCount + ' последовательно × ' + parallelCount + ' параллельно');
        setText('batterySeriesParallel', seriesCount + 'S-' + parallelCount + 'P');
      }

      renderBatterySchematic(item);
    }

    function renderBatterySchematic(item) {
      var schematic = document.getElementById('batterySchematic');
      var grid = document.getElementById('batterySchematicGrid');
      var note = document.getElementById('batterySchematicNote');
      if (!schematic || !grid || !note) return;
      if (!item) {
        schematic.style.display = 'none';
        return;
      }

      var readyBattery = item.mode === 'battery';
      var seriesCount = Math.max(1, parseInt(item.seriesCount || state.requiredSeries || 1, 10));
      var parallelCount = Math.max(1, parseInt(item.parallelCount || item.totalUnits || 1, 10));
      grid.innerHTML = '';

      if (readyBattery) {
        note.textContent = 'Условная схема: готовые батареи подключены параллельно.';
        grid.className = 'battery-schematic-ready';
        for (var p = 0; p < parallelCount; p++) {
          grid.innerHTML += '<div class="battery-schematic-pack">АКБ ' + (p + 1) + '</div>';
        }
      } else {
        note.textContent = 'Номера показывают порядок ячеек в выбранной конфигурации.';
        grid.className = 'battery-schematic-grid';
        var totalCells = seriesCount * parallelCount;
        var layouts = [
          { title: 'Вариант 1: компактный', columns: Math.max(1, Math.ceil(Math.sqrt(totalCells))), depth: 2 },
          { title: 'Вариант 2: низкий и широкий', columns: Math.min(totalCells, Math.max(1, Math.ceil(totalCells / 2))), depth: 2 },
          { title: 'Вариант 3: в длину', columns: totalCells, depth: 1 }
        ];

        for (var layoutIndex = 0; layoutIndex < layouts.length; layoutIndex++) {
          var layout = layouts[layoutIndex];
          var cellsPerLayer = Math.ceil(totalCells / layout.depth);
          var layerColumns = Math.min(layout.columns, cellsPerLayer);
          var layerRows = Math.ceil(cellsPerLayer / layerColumns);
          var option = document.createElement('div');
          option.className = 'battery-schematic-option';
          option.innerHTML = '<div class="battery-schematic-option-title">' + layout.title + ' · ' + layerColumns + ' × ' + layerRows + ' × ' + layout.depth + '</div>';

          var volume = document.createElement('div');
          volume.className = 'battery-schematic-volume';
          for (var layer = 0; layer < layout.depth; layer++) {
            var layerElement = document.createElement('div');
            layerElement.className = 'battery-schematic-layer';
            layerElement.style.setProperty('--layer-columns', layerColumns);
            layerElement.style.setProperty('--layer-x', (layer * 4) + 'px');
            layerElement.style.setProperty('--layer-y', (layer * -4) + 'px');
            for (var cellIndex = layer * cellsPerLayer; cellIndex < Math.min(totalCells, (layer + 1) * cellsPerLayer); cellIndex++) {
              var cell = document.createElement('span');
              cell.className = 'battery-schematic-cell';
              cell.textContent = String(cellIndex + 1);
              cell.title = 'Ячейка ' + (cellIndex + 1);
              layerElement.appendChild(cell);
            }
            volume.appendChild(layerElement);
          }
          option.appendChild(volume);
          grid.appendChild(option);
        }
      }
      schematic.style.display = 'block';
    }

    function switchPowerUnit(nextUnit) {
      var currentUnit = powerUnit.value;
      if (currentUnit === nextUnit) return;

      var avgWatts = toWatts(averagePower.value);
      var maxWatts = toWatts(maxPower.value);

      powerUnit.value = nextUnit;
      averagePower.value = formatPowerForUnit(avgWatts, nextUnit);
      maxPower.value = formatPowerForUnit(maxWatts, nextUnit);

      if (powerUnitWBtn && powerUnitKwBtn) {
        powerUnitWBtn.classList.toggle('is-active', nextUnit === 'w');
        powerUnitKwBtn.classList.toggle('is-active', nextUnit === 'kw');
      }
    }

    function updateBatteryCapacityMode() {
      var isLifepo4 = getActiveBatteryType() === 'lifepo4';
      var isManual = batteryAh.value === 'manual';
      var readyBattery = isReadyBatteryMode();
      var batteryReadyNote = document.getElementById('batteryReadyNote');

      if (batteryAhLabel) {
        if (readyBattery) {
          batteryAhLabel.textContent = calculatorData.label_battery_assembly_ah || 'Ёмкость батарейной сборки заводского исполнения (корпус + ячейки + BMS в сборе)';
        } else if (isLifepo4) {
          batteryAhLabel.textContent = calculatorData.label_battery_ah || 'Емкость ячейки LiFePO4';
        } else {
          batteryAhLabel.textContent = calculatorData.label_battery_ah_default || 'Ёмкость одной батареи, А·ч';
        }
      }

      if (customBatteryWrap) {
        customBatteryWrap.style.display = (!isLifepo4 && isManual) ? '' : 'none';
      }

      if (batteryReadyNote) {
        batteryReadyNote.style.display = readyBattery ? '' : 'none';
      }

      updateCostLabels();
    }


    function updateLifepo4VariantUI() {
      var isLifepo4 = getActiveBatteryType() === 'lifepo4';
      var showVariant = isLifepo4;
      if (groups.lifepo4Variant) {
        groups.lifepo4Variant.style.display = showVariant ? '' : 'none';
      }

      if (lifepo4VariantCellBtn && lifepo4VariantBatteryBtn) {
        lifepo4VariantCellBtn.classList.toggle('is-active', getLifepo4Variant() === 'cell');
        lifepo4VariantBatteryBtn.classList.toggle('is-active', getLifepo4Variant() === 'battery');
        lifepo4VariantCellBtn.disabled = !showVariant;
        lifepo4VariantBatteryBtn.disabled = !showVariant;
      }
    }

    function buildReadyBatteryOptions(voltage, requiredCapacity) {
      var items = [];
      var normalizedVoltage = Math.round(toNumber(voltage));

      for (var i = 0; i < calculatorData.batteries.length; i++) {
        var battery = calculatorData.batteries[i];
        var batteryVoltage = Math.round(toNumber(battery.voltage));
        var batteryCapacity = toNumber(battery.capacity_ah);

        if (batteryCapacity <= 0) continue;
        if (batteryVoltage > 0 && normalizedVoltage > 0 && batteryVoltage !== normalizedVoltage) continue;

        var quantity = Math.max(1, Math.ceil(requiredCapacity / batteryCapacity));
        var totalCapacityAh = batteryCapacity * quantity;
        var packEnergyKwh = ((batteryVoltage || normalizedVoltage || voltage) * totalCapacityAh) / 1000;

        items.push({
          product_id: battery.product_id,
          name: battery.name,
          href: battery.href,
          image: battery.image,
          voltage: batteryVoltage || normalizedVoltage || toNumber(voltage),
          capacity_ah: batteryCapacity,
          parallelCount: quantity,
          totalUnits: quantity,
          totalCapacityAh: totalCapacityAh,
          packEnergyKwh: packEnergyKwh,
          price: toNumber(battery.price),
          mode: 'battery'
        });
      }

      items.sort(function(a, b) {
        var aCost = hasPrice(a) ? a.price * a.totalUnits : Number.POSITIVE_INFINITY;
        var bCost = hasPrice(b) ? b.price * b.totalUnits : Number.POSITIVE_INFINITY;
        if (aCost !== bCost) return aCost - bCost;
        if (a.totalUnits !== b.totalUnits) return a.totalUnits - b.totalUnits;
        return a.capacity_ah - b.capacity_ah;
      });

      return items;
    }

    function getSelectedBatteryItem(items) {
      var source = items || buildReadyBatteryOptions(getWorkingVoltage(), state.requiredCapacity);
      for (var i = 0; i < source.length; i++) {
        if (source[i].product_id === state.selectedCellId) return source[i];
      }
      return source.length ? source[0] : null;
    }

    function renderReadyBatteries(voltage, requiredCapacity) {
      var container = document.getElementById('batteryMatchingCells');
      var bmsContainer = document.getElementById('batteryMatchingBms');
      if (!container) return;

      var batteries = buildReadyBatteryOptions(voltage, requiredCapacity);

      if (!batteries.length) {
        container.innerHTML = '<div class="vc-empty-note">' + escapeHtml(calculatorData.text_no_cells_found || 'Подходящие батареи пока не найдены. Проверьте атрибуты товаров.') + '</div>';
        if (bmsContainer) bmsContainer.innerHTML = '<div class="vc-empty-note">' + escapeHtml(calculatorData.text_battery_ready_note || 'Для готовых сборок дополнительный подбор BMS не требуется.') + '</div>';
        state.selectedCellId = null;
        resetCostSummary();
        return;
      }

      if (!state.selectedCellId || !batteries.some(function(item) { return item.product_id === state.selectedCellId; })) {
        state.selectedCellId = batteries[0].product_id;
      }

      var html = '<div class="vc-product-list">';
      for (var i = 0; i < batteries.length; i++) {
        var item = batteries[i];
        var selectedClass = item.product_id === state.selectedCellId ? ' is-selected' : '';
        html += ''
          + '<div class="vc-product-item' + selectedClass + '">'
          +   getProductImageMarkup(item)
          +   '<div class="vc-product-title">' + escapeHtml(item.name) + '</div>'
          +   '<div class="vc-product-meta">'
          +     '<div>Батарея: ' + item.voltage + ' В / ' + item.capacity_ah + ' А·ч</div>'
          +     '<div>Количество: ' + item.totalUnits + ' шт.</div>'
          +     '<div>Итоговая ёмкость: ' + item.totalCapacityAh + ' А·ч</div>'
          +     '<div>Энергоемкость: ' + item.packEnergyKwh.toFixed(1) + ' кВт·ч</div>'
          +     '<div>Цена за ед.: ' + escapeHtml(getPriceText(item)) + '</div>'
          +     '<div>Итого: ' + escapeHtml(hasPrice(item) ? formatMoney(item.price * item.totalUnits) : (calculatorData.text_price_not_available || 'Цена не указана')) + '</div>'
          +   '</div>'
          +   '<div class="vc-product-actions">'
          +     '<button type="button" class="vc-btn vc-btn-primary js-vc-select-ready-battery" data-product-id="' + item.product_id + '">'
          +       escapeHtml(item.product_id === state.selectedCellId ? (calculatorData.text_selected_cell || 'Выбрано') : (calculatorData.text_select_cell || 'Выбрать'))
          +     '</button>'
          +     '<a class="vc-btn vc-btn-secondary" href="' + escapeHtml(item.href) + '">' + escapeHtml(calculatorData.text_open_product || 'Открыть товар') + '</a>'
          +   '</div>'
          + '</div>';
      }
      html += '</div>';
      container.innerHTML = html;

      if (bmsContainer) {
        bmsContainer.innerHTML = '<div class="vc-empty-note">' + escapeHtml(calculatorData.text_battery_ready_note || 'Для готовых сборок дополнительный подбор BMS не требуется.') + '</div>';
      }

      state.selectedBmsId = null;
      state.totalCells = getSelectedBatteryItem(batteries) ? getSelectedBatteryItem(batteries).totalUnits : 0;
      updateSelectedAssemblySummary(getSelectedBatteryItem(batteries));
      updateCostSummary(getSelectedBatteryItem(batteries), null);

      var buttons = container.querySelectorAll('.js-vc-select-ready-battery');
      for (var k = 0; k < buttons.length; k++) {
        buttons[k].addEventListener('click', function() {
          state.selectedCellId = parseInt(this.getAttribute('data-product-id'), 10);
          renderReadyBatteries(getWorkingVoltage(), state.requiredCapacity);
        });
      }
    }

    function clearProductSections() {
      var cells = document.getElementById('batteryMatchingCells');
      var bms = document.getElementById('batteryMatchingBms');
      if (cells) cells.innerHTML = '';
      if (bms) bms.innerHTML = '';
      resetCostSummary();
    }

    function toggleResult(isVisible) {
      if (resultPlaceholder) {
        resultPlaceholder.style.display = isVisible ? 'none' : '';
      }
      if (resultBody) {
        resultBody.style.display = isVisible ? '' : 'none';
      }
      if (!isVisible) {
        var schematic = document.getElementById('batterySchematic');
        if (schematic) schematic.style.display = 'none';
      }
    }

    function toggleProductSections() {
      var show = getActiveBatteryType() === 'lifepo4';
      if (productsSection) {
        productsSection.style.display = show ? '' : 'none';
      }
      if (!show) {
        clearProductSections();
      }
    }

    function fillBatteryOptions(options, includeManual) {
      var html = '';

      if (options.length) {
        for (var i = 0; i < options.length; i++) {
          html += '<option value="' + escapeHtml(options[i].value) + '">' + escapeHtml(options[i].label) + '</option>';
        }
      } else {
        html += '<option value="">' + escapeHtml(calculatorData.text_no_capacity_values || 'Нет значений ёмкости') + '</option>';
      }

      if (includeManual) {
        html += '<option value="manual">' + escapeHtml(calculatorData.text_manual_capacity || 'Ввести вручную') + '</option>';
      }

      batteryAh.innerHTML = html;
      batteryAh.disabled = false;
      state.batteryOptionsLoaded = options.length > 0 || includeManual;
      updateBatteryCapacityMode();
    }

    function fillStandardBatteryOptions() {
      var options = [];
      for (var i = 0; i < standardBatteryOptions.length; i++) {
        options.push({ value: String(standardBatteryOptions[i]), label: standardBatteryOptions[i] + ' А·ч' });
      }
      fillBatteryOptions(options, true);
    }

    function setBatteryOptionsLoading() {
      batteryAh.innerHTML = '<option value="">' + escapeHtml(calculatorData.text_loading_values || 'Загрузка значений...') + '</option>';
      batteryAh.disabled = true;
      state.batteryOptionsLoaded = false;
      updateBatteryCapacityMode();
    }

    function setBatteryOptionsError() {
      batteryAh.innerHTML = '<option value="">' + escapeHtml(calculatorData.text_failed_load_values || 'Не удалось загрузить ёмкости') + '</option>';
      batteryAh.disabled = true;
      state.batteryOptionsLoaded = false;
      updateBatteryCapacityMode();
    }

    function loadBatteryOptions() {
      toggleResult(false);
      toggleProductSections();
      state.selectedCellId = null;

      if (getActiveBatteryType() !== 'lifepo4') {
        fillStandardBatteryOptions();
        return;
      }

      var url = calculatorData.battery_options_url;
      if (!url) {
        setBatteryOptionsError();
        return;
      }

      setBatteryOptionsLoading();

      var requestUrl = url
        + (url.indexOf('?') === -1 ? '?' : '&')
        + 'battery_type=' + encodeURIComponent('lifepo4')
        + '&variant=' + encodeURIComponent(getLifepo4Variant())
        + '&system_voltage=' + encodeURIComponent(getWorkingVoltage())
        + '&_ts=' + Date.now();

      var xhr = new XMLHttpRequest();
      xhr.open('GET', requestUrl, true);
      xhr.onreadystatechange = function() {
        if (xhr.readyState !== 4) return;

        if (xhr.status < 200 || xhr.status >= 300) {
          setBatteryOptionsError();
          return;
        }

        try {
          var response = JSON.parse(xhr.responseText);
          var options = response && response.options ? response.options : [];
          fillBatteryOptions(options, false);
        } catch (error) {
          setBatteryOptionsError();
        }
      };
      xhr.send();
    }

    function buildCellOptions(requiredSeries, requiredCapacity) {
      var items = [];

      for (var i = 0; i < calculatorData.cells.length; i++) {
        var cell = calculatorData.cells[i];
        var cellVoltage = toNumber(cell.voltage);
        var cellCapacity = toNumber(cell.capacity_ah);

        if (cellVoltage <= 0 || cellCapacity <= 0) continue;
        if (Math.abs(cellVoltage - 3.2) > 0.2) continue;

        var parallelCount = Math.max(1, Math.ceil(requiredCapacity / cellCapacity));
        var totalCells = requiredSeries * parallelCount;
        var totalCapacityAh = cellCapacity * parallelCount;
        var packVoltage = requiredSeries * cellVoltage;
        var packEnergyKwh = (packVoltage * totalCapacityAh) / 1000;

        items.push({
          product_id: cell.product_id,
          name: cell.name,
          href: cell.href,
          image: cell.image,
          voltage: cellVoltage,
          capacity_ah: cellCapacity,
          seriesCount: requiredSeries,
          parallelCount: parallelCount,
          totalCells: totalCells,
          totalCapacityAh: totalCapacityAh,
          packEnergyKwh: packEnergyKwh,
          price: toNumber(cell.price)
        });
      }

      items.sort(function(a, b) {
        var aCost = hasPrice(a) ? a.price * a.totalCells : Number.POSITIVE_INFINITY;
        var bCost = hasPrice(b) ? b.price * b.totalCells : Number.POSITIVE_INFINITY;
        if (aCost !== bCost) return aCost - bCost;
        if (a.totalCells !== b.totalCells) return a.totalCells - b.totalCells;
        return a.capacity_ah - b.capacity_ah;
      });

      return items;
    }

    function buildBmsOptions(requiredSeries, requiredCurrent) {
      var items = [];

      for (var i = 0; i < calculatorData.bms.length; i++) {
        var bms = calculatorData.bms[i];
        var minS = parseInt(bms.min_s, 10) || 0;
        var maxS = parseInt(bms.max_s, 10) || 0;
        var maxCurrentA = toNumber(bms.max_current_a);
        var currentMatches = requiredCurrent > 0 ? maxCurrentA >= requiredCurrent : true;

        if (minS <= requiredSeries && maxS >= requiredSeries && currentMatches) {
          items.push({
            product_id: bms.product_id,
            name: bms.name,
            href: bms.href,
            image: bms.image,
            minS: minS,
            maxS: maxS,
            maxCurrentA: maxCurrentA,
            price: toNumber(bms.price)
          });
        }
      }

      items.sort(function(a, b) {
        if (hasPrice(a) && !hasPrice(b)) return -1;
        if (!hasPrice(a) && hasPrice(b)) return 1;
        if (hasPrice(a) && hasPrice(b) && a.price !== b.price) return a.price - b.price;
        return a.maxCurrentA - b.maxCurrentA;
      });

      return items;
    }

    function renderBms(items) {
      var container = document.getElementById('batteryMatchingBms');
      if (!container) return;

      if (!items.length) {
        container.innerHTML = '<div class="vc-empty-note">' + escapeHtml(calculatorData.text_no_bms_found || 'Нет подходящих BMS') + '</div>';
        state.selectedBmsId = null;
        updateCostSummary(getSelectedCellItem(), null);
        return;
      }

      if (!state.selectedBmsId || !items.some(function(item) { return item.product_id === state.selectedBmsId; })) {
        state.selectedBmsId = items[0].product_id;
      }

      var currentText = state.requiredCurrent > 0
        ? state.requiredCurrent.toFixed(1) + ' А'
        : (calculatorData.text_current_not_set || 'не задан');

      var html = '<div class="vc-product-list">';
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var selectedClass = item.product_id === state.selectedBmsId ? ' is-selected' : '';
        html += ''
          + '<div class="vc-product-item' + selectedClass + '">'
          +   getProductImageMarkup(item)
          +   '<div class="vc-product-title">' + escapeHtml(item.name) + '</div>'
          +   '<div class="vc-product-meta">'
          +     '<div>Поддержка сборки: ' + item.minS + 'S - ' + item.maxS + 'S</div>'
          +     '<div>Максимальный ток: ' + item.maxCurrentA + ' А</div>'
          +     '<div>Требуемый ток: ' + escapeHtml(currentText) + '</div>'
          +     '<div>Количество: 1 шт.</div>'
          +     '<div>Цена за ед.: ' + escapeHtml(getPriceText(item)) + '</div>'
          +     '<div>Итого: ' + escapeHtml(hasPrice(item) ? formatMoney(item.price) : (calculatorData.text_price_not_available || 'Цена не указана')) + '</div>'
          +   '</div>'
          +   '<div class="vc-product-actions">'
          +     '<button type="button" class="vc-btn vc-btn-primary js-vc-select-bms" data-product-id="' + item.product_id + '">'
          +       escapeHtml(item.product_id === state.selectedBmsId ? (calculatorData.text_selected_bms || 'Выбрано') : (calculatorData.text_select_bms || 'Выбрать'))
          +     '</button>'
          +     '<a class="vc-btn vc-btn-secondary" href="' + escapeHtml(item.href) + '">' + escapeHtml(calculatorData.text_open_product || 'Открыть товар') + '</a>'
          +   '</div>'
          + '</div>';
      }
      html += '</div>';
      container.innerHTML = html;

      var selectedBms = getSelectedBmsItem(items);
      updateCostSummary(getSelectedCellItem(), selectedBms);

      var buttons = container.querySelectorAll('.js-vc-select-bms');
      for (var k = 0; k < buttons.length; k++) {
        buttons[k].addEventListener('click', function() {
          state.selectedBmsId = parseInt(this.getAttribute('data-product-id'), 10);
          renderBms(items);
        });
      }
    }

    function getSelectedCellItem(items) {
      var source = items || (isReadyBatteryMode() ? buildReadyBatteryOptions(getWorkingVoltage(), state.requiredCapacity) : buildCellOptions(state.requiredSeries, state.requiredCapacity));
      for (var i = 0; i < source.length; i++) {
        if (source[i].product_id === state.selectedCellId) return source[i];
      }
      return source.length ? source[0] : null;
    }

    function getSelectedBmsItem(items) {
      var source = items || buildBmsOptions(state.requiredSeries, state.requiredCurrent);
      for (var i = 0; i < source.length; i++) {
        if (source[i].product_id === state.selectedBmsId) return source[i];
      }
      return source.length ? source[0] : null;
    }

    function renderCells(requiredSeries, requiredCapacity) {
      var container = document.getElementById('batteryMatchingCells');
      if (!container) return;

      var cells = buildCellOptions(requiredSeries, requiredCapacity);

      if (!cells.length) {
        container.innerHTML = '<div class="vc-empty-note">' + escapeHtml(calculatorData.text_no_cells_found || 'Нет подходящих ячеек') + '</div>';
        renderBms([]);
        state.selectedCellId = null;
        return;
      }

      if (!state.selectedCellId || !cells.some(function(item) { return item.product_id === state.selectedCellId; })) {
        state.selectedCellId = cells[0].product_id;
      }

      var html = '<div class="vc-product-list">';
      for (var i = 0; i < cells.length; i++) {
        var item = cells[i];
        var selectedClass = item.product_id === state.selectedCellId ? ' is-selected' : '';
        html += ''
          + '<div class="vc-product-item' + selectedClass + '">'
          +   getProductImageMarkup(item)
          +   '<div class="vc-product-title">' + escapeHtml(item.name) + '</div>'
          +   '<div class="vc-product-meta">'
          +     '<div>Ячейка: ' + item.voltage.toFixed(1) + ' В / ' + item.capacity_ah + ' А·ч</div>'
          +     '<div>Сборка: ' + item.seriesCount + 'S-' + item.parallelCount + 'P</div>'
          +     '<div>Всего ячеек: ' + item.totalCells + ' шт.</div>'
          +     '<div>Итоговая ёмкость: ' + item.totalCapacityAh + ' А·ч</div>'
          +     '<div>Энергоемкость: ' + item.packEnergyKwh.toFixed(1) + ' кВт·ч</div>'
          +     '<div>Цена за ед.: ' + escapeHtml(getPriceText(item)) + '</div>'
          +     '<div>Итого: ' + escapeHtml(hasPrice(item) ? formatMoney(item.price * item.totalCells) : (calculatorData.text_price_not_available || 'Цена не указана')) + '</div>'
          +   '</div>'
          +   '<div class="vc-product-actions">'
          +     '<button type="button" class="vc-btn vc-btn-primary js-vc-select-cell" data-product-id="' + item.product_id + '">'
          +       escapeHtml(item.product_id === state.selectedCellId ? (calculatorData.text_selected_cell || 'Выбрано') : (calculatorData.text_select_cell || 'Выбрать'))
          +     '</button>'
          +     '<a class="vc-btn vc-btn-secondary" href="' + escapeHtml(item.href) + '">' + escapeHtml(calculatorData.text_open_product || 'Открыть товар') + '</a>'
          +   '</div>'
          + '</div>';
      }
      html += '</div>';
      container.innerHTML = html;

      var bmsItems = buildBmsOptions(requiredSeries, state.requiredCurrent);
      state.totalCells = getSelectedCellItem(cells) ? getSelectedCellItem(cells).totalCells : 0;
      updateSelectedAssemblySummary(getSelectedCellItem(cells));
      renderBms(bmsItems);
      updateCostSummary(getSelectedCellItem(cells), getSelectedBmsItem(bmsItems));

      var buttons = container.querySelectorAll('.js-vc-select-cell');
      for (var k = 0; k < buttons.length; k++) {
        buttons[k].addEventListener('click', function() {
          state.selectedCellId = parseInt(this.getAttribute('data-product-id'), 10);
          renderCells(state.requiredSeries, state.requiredCapacity);
        });
      }
    }

    function updateModeUI() {
      var custom = isCustomMode();
      if (calcModeUpsBtn && calcModeCustomBtn) {
        calcModeUpsBtn.classList.toggle('is-active', !custom);
        calcModeCustomBtn.classList.toggle('is-active', custom);
      }

      if (groups.powerUnit) groups.powerUnit.style.display = custom ? 'none' : '';
      if (groups.loadPower) groups.loadPower.style.display = custom ? 'none' : '';
      if (groups.maxLoadPower) groups.maxLoadPower.style.display = custom ? 'none' : '';
      if (groups.backupTime) groups.backupTime.style.display = custom ? 'none' : '';
      if (groups.batteryType) groups.batteryType.style.display = custom ? 'none' : '';
      if (groups.efficiency) groups.efficiency.style.display = custom ? 'none' : '';
      if (groups.reserve) groups.reserve.style.display = custom ? 'none' : '';
      if (groups.requiredCapacity) groups.requiredCapacity.style.display = custom ? '' : 'none';
      if (groups.customCurrent) groups.customCurrent.style.display = custom ? '' : 'none';

      if (systemVoltageCustomOption) {
        systemVoltageCustomOption.hidden = !custom;
      }

      if (custom) {
        state.lastUpsBatteryType = batteryType.value;
        batteryType.value = 'lifepo4';
      } else if (state.lastUpsBatteryType) {
        batteryType.value = state.lastUpsBatteryType;
        if (systemVoltage.value === 'custom') {
          systemVoltage.value = '48';
        }
      }

      var showSeries = custom && systemVoltage.value === 'custom';
      if (groups.customSeries) groups.customSeries.style.display = showSeries ? '' : 'none';
      if (groups.customVoltageHelp) groups.customVoltageHelp.style.display = showSeries ? '' : 'none';

      var batteryCapacityGroup = document.getElementById('groupBatteryAh');
      if (batteryCapacityGroup) batteryCapacityGroup.style.display = custom ? 'none' : '';
      if (custom && lifepo4Variant) lifepo4Variant.value = 'cell';

      updateLifepo4VariantUI();
      if (groups.lifepo4Variant) groups.lifepo4Variant.style.display = custom ? 'none' : '';
      updateBatteryCapacityMode();
      toggleProductSections();
      loadBatteryOptions();
    }

    function calculate() {
      var capacityAh = getSelectedCapacityAh();
      if (!state.batteryOptionsLoaded || capacityAh <= 0) {
        toggleResult(false);
        toggleProductSections();
        clearProductSections();
        return;
      }

      var mode = getCalcMode();
      var type = getActiveBatteryType();
      var voltage = getWorkingVoltage();
      var seriesCount = getSeriesForCurrentMode();
      var parallelCount = 1;
      var totalCount = 0;
      var baseCapacity = 0;
      var recommendedCapacity = 0;
      var requiredCurrent = 0;
      var nominalLoadEnergyWh = 0;
      var packEnergyKwh = 0;
      var recommendationText = '';

      if (mode === 'custom') {
        recommendedCapacity = Math.max(0.1, toNumber(requiredCapacityAh.value));
        baseCapacity = recommendedCapacity;
        parallelCount = Math.max(1, Math.ceil(recommendedCapacity / capacityAh));
        if (isReadyBatteryMode()) {
          seriesCount = 1;
          totalCount = parallelCount;
          packEnergyKwh = (voltage * capacityAh * parallelCount) / 1000;
          recommendationText = 'Готовая сборка LiFePO4 со встроенной BMS';
        } else {
          totalCount = seriesCount * parallelCount;
          packEnergyKwh = (seriesCount * 3.2 * capacityAh * parallelCount) / 1000;
          recommendationText = 'Кастомная сборка LiFePO4';
        }
        nominalLoadEnergyWh = voltage * recommendedCapacity;
        requiredCurrent = Math.max(0, toNumber(customMaxCurrent.value));
      } else {
        var avgPowerW = Math.max(1, toWatts(averagePower.value));
        var maxPowerW = Math.max(avgPowerW, toWatts(maxPower.value));
        var hours = Math.max(1, toNumber(backupTime.value)) / 60;
        var eff = Math.min(100, Math.max(1, toNumber(efficiency.value))) / 100;
        var reserve = Math.max(0, toNumber(reservePercent.value)) / 100;
        var dod = batteryProfiles[type] ? batteryProfiles[type].dod : 0.6;

        baseCapacity = (avgPowerW * hours) / (voltage * eff * dod);
        recommendedCapacity = baseCapacity * (1 + reserve);
        if (isReadyBatteryMode()) {
          seriesCount = 1;
          parallelCount = Math.max(1, Math.ceil(recommendedCapacity / capacityAh));
          totalCount = parallelCount;
          packEnergyKwh = (voltage * capacityAh * parallelCount) / 1000;
          recommendationText = 'Готовая сборка LiFePO4 со встроенной BMS';
        } else {
          seriesCount = type === 'lifepo4' ? getSeriesForCurrentMode() : Math.max(1, Math.round(voltage / 12));
          parallelCount = Math.max(1, Math.ceil(recommendedCapacity / capacityAh));
          totalCount = seriesCount * parallelCount;
          packEnergyKwh = (voltage * capacityAh * parallelCount) / 1000;
          recommendationText = (batteryProfiles[type] && batteryProfiles[type].text) ? batteryProfiles[type].text : 'Рекомендация не найдена';
        }
        nominalLoadEnergyWh = avgPowerW * hours;
        requiredCurrent = maxPowerW / Math.max(voltage, 0.1);
      }

      state.requiredSeries = isReadyBatteryMode() ? 1 : (type === 'lifepo4' ? seriesCount : Math.max(1, Math.round(voltage / 12)));
      state.requiredCapacity = recommendedCapacity;
      state.requiredCurrent = requiredCurrent;
      state.totalCells = totalCount;

      var actualCapacity = capacityAh * parallelCount;
      var capacityNote = calculatorData.text_actual_capacity_note || 'Фактическая ёмкость подобранного АКБ';

      setText('requiredCapacity', ceilToOneDecimal(actualCapacity) + ' А·ч');
      setText('requiredCapacityNote', capacityNote);
      setText('calculatedCapacity', ceilToOneDecimal(recommendedCapacity) + ' А·ч');
      setText('calculatedCapacityNote', calculatorData.text_required_capacity_calc_note || 'Требуемая ёмкость АКБ по расчёту');
      setText('baseCapacity', ceilToOneDecimal(actualCapacity) + ' А·ч');
      if (isReadyBatteryMode()) {
        setText('batteryConfig', '1 готовая сборка × ' + parallelCount + ' параллельно');
        setText('batterySeriesParallel', Math.round(voltage) + 'V-' + parallelCount + 'P');
      } else {
        setText('batteryConfig', seriesCount + ' последовательно × ' + parallelCount + ' параллельно');
        setText('batterySeriesParallel', seriesCount + 'S-' + parallelCount + 'P');
      }
      setText('batteryCountBadge', totalCount + ' шт.');
      setText('batteryCount', totalCount + ' шт.');
      setText('energyWh', Math.round(nominalLoadEnergyWh) + ' Вт·ч');
      setText('energyKwh', packEnergyKwh.toFixed(1) + ' кВт·ч');
      setText('typeRecommendation', recommendationText);

      toggleResult(true);
      toggleProductSections();

      if (type === 'lifepo4') {
        if (isReadyBatteryMode()) {
          renderReadyBatteries(voltage, recommendedCapacity);
        } else {
          renderCells(state.requiredSeries, recommendedCapacity);
        }
      } else {
        clearProductSections();
      }
    }

    function createProjectOrder() {
      var selectedCell = getSelectedCellItem();
      if (!selectedCell) return;

      var selectedBms = getSelectedBmsItem();
      var orderUrl = calculatorData.order_create_url;
      if (!orderUrl) {
        window.location.href = calculatorData.cart_url || '/index.php?route=checkout/cart';
        return;
      }

      var cellQty = selectedCell.totalCells || selectedCell.totalUnits || state.totalCells || 0;
      var bmsQty = selectedBms ? 1 : 0;
      var payload = [
        'cell_product_id=' + encodeURIComponent(selectedCell.product_id),
        'cell_qty=' + encodeURIComponent(cellQty),
        'bms_product_id=' + encodeURIComponent(selectedBms ? selectedBms.product_id : 0),
        'bms_qty=' + encodeURIComponent(bmsQty),
        'calc_mode=' + encodeURIComponent(getCalcMode()),
        'system_voltage=' + encodeURIComponent(getWorkingVoltage().toFixed(1)),
        'series=' + encodeURIComponent(state.requiredSeries),
        'parallel=' + encodeURIComponent(Math.max(1, selectedCell.parallelCount || 1)),
        'required_capacity_ah=' + encodeURIComponent(state.requiredCapacity.toFixed(1)),
        'total_cost=' + encodeURIComponent(document.getElementById('costGrandTotal') ? document.getElementById('costGrandTotal').textContent : '')
      ].join('&');

      var xhr = new XMLHttpRequest();
      xhr.open('POST', orderUrl, true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
      xhr.onreadystatechange = function() {
        if (xhr.readyState !== 4) return;

        if (xhr.status < 200 || xhr.status >= 300) {
          alert(calculatorData.text_order_project_error || 'Не удалось сформировать заказ по этой сборке.');
          return;
        }

        try {
          var response = JSON.parse(xhr.responseText);
          if (response && response.success && response.redirect) {
            window.location.href = response.redirect;
            return;
          }
        } catch (e) {}

        alert(calculatorData.text_order_project_error || 'Не удалось сформировать заказ по этой сборке.');
      };
      xhr.send(payload);
    }

    batteryType.addEventListener('change', function() {
      state.lastUpsBatteryType = batteryType.value;
      if (batteryType.value !== 'lifepo4' && lifepo4Variant) {
        lifepo4Variant.value = 'cell';
      }
      updateLifepo4VariantUI();
      updateBatteryCapacityMode();
      loadBatteryOptions();
    });

    systemVoltage.addEventListener('change', function() {
      if (groups.customSeries) groups.customSeries.style.display = (isCustomMode() && systemVoltage.value === 'custom') ? '' : 'none';
      if (groups.customVoltageHelp) groups.customVoltageHelp.style.display = (isCustomMode() && systemVoltage.value === 'custom') ? '' : 'none';
      loadBatteryOptions();
    });

    if (customSeries) {
      customSeries.addEventListener('change', function() {
        if (isCustomMode() && systemVoltage.value === 'custom') {
          loadBatteryOptions();
        }
      });
    }


    if (lifepo4VariantCellBtn && lifepo4VariantBatteryBtn && lifepo4Variant) {
      lifepo4VariantCellBtn.addEventListener('click', function() {
        lifepo4Variant.value = 'cell';
        updateLifepo4VariantUI();
        updateBatteryCapacityMode();
        loadBatteryOptions();
      });

      lifepo4VariantBatteryBtn.addEventListener('click', function() {
        lifepo4Variant.value = 'battery';
        updateLifepo4VariantUI();
        updateBatteryCapacityMode();
        loadBatteryOptions();
      });
    }

    batteryAh.addEventListener('change', updateBatteryCapacityMode);
    calculateButton.addEventListener('click', calculate);

    if (calculateOrderButton) {
      calculateOrderButton.addEventListener('click', createProjectOrder);
    }

    if (powerUnitWBtn && powerUnitKwBtn) {
      powerUnitWBtn.addEventListener('click', function() { switchPowerUnit('w'); });
      powerUnitKwBtn.addEventListener('click', function() { switchPowerUnit('kw'); });
    }

    if (calcModeUpsBtn && calcModeCustomBtn) {
      calcModeUpsBtn.addEventListener('click', function() {
        calcMode.value = 'ups';
        updateModeUI();
      });
      calcModeCustomBtn.addEventListener('click', function() {
        calcMode.value = 'custom';
        updateModeUI();
      });
    }

    switchPowerUnit('w');
    updateBatteryCapacityMode();
    toggleResult(false);
    toggleProductSections();
    updateModeUI();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBatteryCalculator);
  } else {
    initBatteryCalculator();
  }
})();
